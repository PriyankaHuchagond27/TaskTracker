package com.workgen.tasktracker;

import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {
    private final TaskRepository repository;

    public TaskController(TaskRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public Page<Task> getTasks(
            @RequestParam(required = false, defaultValue = "") String q,
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int pageSize) {

        TaskStatus taskStatus = null;
        if (status != null && !status.isBlank() && !status.equalsIgnoreCase("ALL")) {
            try {
                taskStatus = TaskStatus.valueOf(status.toUpperCase());
            } catch (IllegalArgumentException ex) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Invalid status. Use NOT_STARTED, IN_PROGRESS, DONE, OVERDUE or PAUSED.");
            }
        }

        int safePage = Math.max(0, page);
        int safeSize = Math.min(100, Math.max(1, pageSize));
        String search = q == null || q.isBlank() ? null : q.trim();

        return repository.searchTasks(search, taskStatus,
                PageRequest.of(safePage, safeSize, Sort.by(Sort.Direction.DESC, "id")));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Task createTask(@Valid @RequestBody Task task) {
        task.setId(null);
        task.setArchived(false);
        if (task.getStatus() == null) task.setStatus(TaskStatus.NOT_STARTED);
        if (task.getPriority() == null || task.getPriority().isBlank()) task.setPriority("Medium");
        return repository.save(task);
    }

    @PutMapping("/{id}")
    public Task updateTask(@PathVariable Long id, @Valid @RequestBody Task input) {
        Task task = repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Task not found"));
        task.setTitle(input.getTitle());
        task.setAssignee(input.getAssignee());
        task.setProject(input.getProject());
        task.setDueDate(input.getDueDate());
        task.setStatus(input.getStatus() == null ? task.getStatus() : input.getStatus());
        task.setPriority(input.getPriority() == null ? task.getPriority() : input.getPriority());
        return repository.save(task);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void archiveTask(@PathVariable Long id) {
        Task task = repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Task not found"));
        task.setArchived(true);
        repository.save(task);
    }

    @GetMapping("/stats")
    public Map<String, Long> getStats() {
        var tasks = repository.findAll().stream().filter(t -> !t.isArchived()).toList();
        long total = tasks.size();
        long done = tasks.stream().filter(t -> t.getStatus() == TaskStatus.DONE).count();
        long progress = tasks.stream().filter(t -> t.getStatus() == TaskStatus.IN_PROGRESS).count();
        long overdue = tasks.stream().filter(t -> t.getStatus() == TaskStatus.OVERDUE).count();
        long pending = tasks.stream().filter(t -> t.getStatus() == TaskStatus.NOT_STARTED).count();
        return Map.of("total", total, "done", done, "inProgress", progress,
                "overdue", overdue, "pending", pending);
    }
}
