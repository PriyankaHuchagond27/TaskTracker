package com.workgen.tasktracker;

public enum TaskStatus {
    NOT_STARTED, IN_PROGRESS, DONE, OVERDUE, PAUSED
}
