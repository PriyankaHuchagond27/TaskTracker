package com.workgen.tasktracker;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TaskRepository extends JpaRepository<Task, Long> {
    @Query("""
        SELECT t FROM Task t
        WHERE t.archived = false
          AND (:status IS NULL OR t.status = :status)
          AND (:q IS NULL OR LOWER(t.title) LIKE LOWER(CONCAT('%', :q, '%'))
               OR LOWER(COALESCE(t.project, '')) LIKE LOWER(CONCAT('%', :q, '%'))
               OR LOWER(COALESCE(t.assignee, '')) LIKE LOWER(CONCAT('%', :q, '%')))
        """)
    Page<Task> searchTasks(@Param("q") String q,
                           @Param("status") TaskStatus status,
                           Pageable pageable);
}
