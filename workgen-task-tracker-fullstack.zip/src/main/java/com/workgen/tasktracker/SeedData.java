package com.workgen.tasktracker;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;

@Configuration
public class SeedData {
    @Bean
    CommandLineRunner seedTasks(TaskRepository repository) {
        return args -> {
            if (repository.count() > 0) return;
            repository.save(new Task("Frontend Bug Fixes", "Ben Watson", "Northbridge CRM",
                    LocalDate.now().plusDays(2), TaskStatus.DONE, "High"));
            repository.save(new Task("SEO Optimization", "Unassigned", "DocFlow Vault",
                    LocalDate.now().minusDays(1), TaskStatus.OVERDUE, "Medium"));
            repository.save(new Task("Landing Page Design", "Ben Watson", "IronGate Security",
                    LocalDate.now().plusDays(1), TaskStatus.IN_PROGRESS, "High"));
            repository.save(new Task("Dashboard Redesign", "Alex Morgan", "Finch Ledger",
                    LocalDate.now().plusDays(3), TaskStatus.PAUSED, "Medium"));
            repository.save(new Task("Onboarding Workflow Design", "Unassigned", "Nexa",
                    LocalDate.now().plusDays(5), TaskStatus.NOT_STARTED, "Low"));
            for (int i = 0; i < 12; i++) {
                repository.save(new Task("Task Planning " + (i + 1), "Alex Morgan", "Workgen",
                        LocalDate.now().plusDays(i + 1), TaskStatus.NOT_STARTED, "Medium"));
            }
        };
    }
}
