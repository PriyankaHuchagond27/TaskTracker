# Workgen Task Tracker (Frontend + Backend)

## Tech stack
- Frontend: HTML, CSS, JavaScript
- Backend: Java 17 + Spring Boot REST API
- Database: H2 file database (data persists locally)

## Requirements
- Java 17+
- Maven 3.8+ (or open/import this folder in IntelliJ IDEA)

## Run
From this project folder, run:

    mvn spring-boot:run

Then open:
- App: http://localhost:8080
- Tasks API: http://localhost:8080/api/tasks
- Stats API: http://localhost:8080/api/tasks/stats
- H2 console: http://localhost:8080/h2-console

H2 console JDBC URL:
    jdbc:h2:file:./data/workgen-tasks
Username: sa
Password: (leave blank)

## Features
- Task listing from backend API
- Search by task title, project, or assignee
- Filter by task status
- Pagination
- Create task
- Archive task
- Live summary cards
- Seeded sample tasks on first run

## API examples
GET /api/tasks?q=design&page=0&pageSize=10&status=ALL
POST /api/tasks
Content-Type: application/json

{
  "title": "Update homepage",
  "assignee": "Ben Watson",
  "project": "Workgen",
  "dueDate": "2026-10-20",
  "status": "IN_PROGRESS",
  "priority": "High"
}

DELETE /api/tasks/1

Note: This is a starter project for learning. The screenshot's brand and example task data are approximated; it is not the original Workgen service.
